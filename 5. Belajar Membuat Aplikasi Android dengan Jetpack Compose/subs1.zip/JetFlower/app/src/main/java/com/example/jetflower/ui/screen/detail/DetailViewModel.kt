package com.example.jetflower.ui.screen.detail

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.jetflower.data.FlowerItem
import com.example.jetflower.data.FlowerModel
import com.example.jetflower.data.Repository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import com.example.jetflower.data.Result

class DetailViewModel (private val repository: Repository) : ViewModel() {

    private val _state : MutableStateFlow<Result<FlowerItem>> = MutableStateFlow(Result.Loading)
    val state: StateFlow<Result<FlowerItem>>
        get() = _state

    fun getFlowerId(flowerId : Long){
        viewModelScope.launch {
            _state.value = Result.Loading
            _state.value = Result.Success(repository.getFlowerId(flowerId))
        }
    }

    fun addToCheckout(flowerModel : FlowerModel, count : Int){
        viewModelScope.launch {
            repository.updateFlower(flowerModel.id, count)
        }
    }
}