package com.example.jetflower.ui.theme

import androidx.compose.ui.graphics.Color

val TaupeGray = Color(0xFF887880)
val Blue = Color(0xFF7D98A1)
val Black = Color(0xFF5E6572)
val Pink = Color(0xFFEF8275)