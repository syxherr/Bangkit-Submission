package com.example.jetflower.ui.screen.home

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.jetflower.data.FlowerItem
import com.example.jetflower.data.Repository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import com.example.jetflower.data.Result
import com.example.jetflower.ui.components.SearchState
import kotlinx.coroutines.flow.catch

class HomeViewModel (private val repository : Repository) : ViewModel() {

    private val _state : MutableStateFlow<Result<List<FlowerItem>>> = MutableStateFlow(Result.Loading)
    val state: StateFlow<Result<List<FlowerItem>>>
        get() = _state

    fun getAllFlower(){
        viewModelScope.launch {
            repository.getAllFlower()
                .catch {
                    _state.value = Result.Error(it.message.toString())
                }
                .collect { flowerItem ->
                    _state.value = Result.Success(flowerItem)
                }
        }
    }

    //membuat fungsi perncaharian
    private val _searchState = mutableStateOf(SearchState())
    val searchState: androidx.compose.runtime.State<SearchState> = _searchState

    private fun searchItems(query : String){
        viewModelScope.launch(Dispatchers.IO) {
            repository.searchItems(query)
                .catch { _state.value = Result.Error(it.message.toString()) }
                .collect { _state.value = Result.Success(it) }
        }
    }

    fun onQueryChange(query : String){
        _searchState.value = _searchState.value.copy(query = query)
        searchItems(query)
    }
}