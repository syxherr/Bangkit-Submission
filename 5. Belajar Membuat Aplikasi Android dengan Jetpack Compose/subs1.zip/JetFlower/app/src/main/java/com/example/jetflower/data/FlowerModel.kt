package com.example.jetflower.data


data class FlowerModel(
    val id: Long,
    val title: String,
    val description: String,
    val photo: Int,
    val price: Int
)