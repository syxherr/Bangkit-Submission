package com.example.jetflower.ui.components

data class SearchState(
    val query : String = ""
)
