package com.example.jetflower.ui.screen.detail

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Devices
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.jetflower.R
import com.example.jetflower.data.Result
import com.example.jetflower.di.Injection
import com.example.jetflower.ui.ViewModelFactory
import com.example.jetflower.ui.components.BuyBotton
import com.example.jetflower.ui.components.Counter
import com.example.jetflower.ui.theme.JetFlowerTheme

@Composable
fun DetailScreen (
    flowerId : Long,
    viewModel: DetailViewModel = viewModel(
        factory = ViewModelFactory(
            Injection.provideRepository()
        )
    ),
    navigateBack : () -> Unit,
    navigateToCart: () -> Unit,
){

    viewModel.state.collectAsState(initial = Result.Loading).value.let { state ->
        when(state){
            is Result.Loading -> {
                viewModel.getFlowerId(flowerId)
            }
            is Result.Success -> {
                val item = state.data
                DetailContent(
                    title = item.flower.title,
                    photo = item.flower.photo,
                    description = item.flower.description ,
                    price = item.flower.price,
                    count = item.count,
                    onBackClick = navigateBack,
                    onAddToCart = {count ->
                        viewModel.addToCheckout(item.flower, count)
                        navigateToCart()
                    }
                )
            }

            else -> {}
        }

    }

}

//content
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailContent(
    title: String,
    @DrawableRes photo : Int,
    description : String,
    price : Int,
    count : Int,
    onBackClick: () -> Unit,
    onAddToCart: (count: Int) -> Unit,
    modifier: Modifier = Modifier,
){
    var totalPoint by rememberSaveable { mutableStateOf(0) }
    var orderCount by rememberSaveable { mutableStateOf(count) }

    Column(modifier = modifier) {
        CenterAlignedTopAppBar(
            title = {
                Text(
                    text = stringResource(R.string.detail_text) ,
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp)
                )
            },
            navigationIcon = {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = stringResource(R.string.back_text),
                    modifier = Modifier
                        .padding(15.dp)
                        .clickable { onBackClick() }
                )

            }
        )
        Column(
            modifier = Modifier
                .verticalScroll(rememberScrollState())
                .weight(1f)
        ) {
            Box{
                Image(
                    painter = painterResource(photo),
                    contentDescription = "Photo Item",
                    contentScale = ContentScale.Crop,
                    modifier = modifier
                        .height(400.dp)
                        .width(400.dp)
                        .padding(23.dp)
                        .clip(RoundedCornerShape(bottomStart = 18.dp, bottomEnd = 18.dp))                )
            }
            Column(
                horizontalAlignment = Alignment.Start,
                modifier = Modifier.padding(16.dp)
            ) {
                Text(
                    text = title,
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.headlineLarge.copy(
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 30.sp,
                    ),
                )
                Text(
                    text = stringResource(id = R.string.required_point, price),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Medium
                    ),
                    color = MaterialTheme.colorScheme.secondary,
                )

                Spacer(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(16.dp)
                )

                Text(
                    text = stringResource(id = R.string.Description),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Medium
                    ),
                    modifier = modifier
                        .padding(vertical = 10.dp)

                )
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Start
                )

            }
        }

        Spacer(
            modifier = Modifier
                .fillMaxWidth()
                .height(2.dp)
        )

        Row(
            modifier = Modifier.padding(16.dp)
        ) {

            Counter(
                orderId = 1,
                orderCount = orderCount,
                onProductIncreased = {orderCount++},
                onProductDecreased = { if(orderCount > 0) orderCount-- }
            )
            Spacer(modifier = Modifier.width(30.dp))
            totalPoint = price * orderCount
            BuyBotton(
                text = stringResource(R.string.add_to_cart, totalPoint),
                enabled = orderCount > 0,
                onClick = {
                    onAddToCart(orderCount)
                },
                modifier = Modifier.align(Alignment.CenterVertically)
            )
        }
    }
}

@Preview(showBackground = true, device = Devices.NEXUS_6P)
@Composable
fun DetailContentPreview(){
    JetFlowerTheme {
        DetailContent(
            "Dahlia",
            R.drawable.dahlia,
            "Bunga dahlia menarik perhatian dengan kepala bunga yang besar dan variasi warna yang luas. Dahlia adalah bunga yang penuh warna dan menawan, melambangkan keanggunan dan kemegahan.\n" +
                    "Mereka dapat ditemukan dalam berbagai bentuk, mulai dari bunga berpenuh hingga bunga dengan kelopak bergelombang.",
            90000,
            1,
            onBackClick = {  },
            onAddToCart = {}
        )
    }
}
