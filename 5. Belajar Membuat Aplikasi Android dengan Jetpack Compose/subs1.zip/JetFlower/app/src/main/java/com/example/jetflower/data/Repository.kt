package com.example.jetflower.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map

class Repository {
    private val flowerItem = mutableListOf<FlowerItem>()

    init {
        if (flowerItem.isEmpty()) {
            FlowerData.flowerModels.forEach {
                flowerItem.add(FlowerItem(it, 0))
            }
        }
    }

    fun getAllFlower(): Flow<List<FlowerItem>> {
        return flowOf(flowerItem)
    }

    fun getFlowerId(flowerId: Long): FlowerItem {
        return flowerItem.first {
            it.flower.id == flowerId
        }
    }

    fun updateFlower(flowerId: Long, newCountValue: Int): Flow<Boolean> {
        val index = flowerItem.indexOfFirst { it.flower.id == flowerId }
        val result = if (index >= 0) {
            val buyFlower = flowerItem[index]
            flowerItem[index] =
                buyFlower.copy(flower = buyFlower.flower, count = newCountValue)
            true
        } else {
            false
        }
        return flowOf(result)
    }

    fun getAddFlower(): Flow<List<FlowerItem>> {
        return getAllFlower()
            .map { flowerItem ->
                flowerItem.filter { buyFlower ->
                    buyFlower.count != 0
                }
            }
    }

    fun searchItems(query : String) : Flow<List<FlowerItem>> {
        return getAllFlower()
            .map { result ->
                result.filter {
                    it.flower.title.contains(query, ignoreCase = true)
                }
            }
    }
    companion object {
        @Volatile
        private var instance: Repository? = null
        fun getInstance(): Repository =
            instance ?: synchronized(this) {
                Repository().apply {
                    instance = this
                }
            }
    }
}