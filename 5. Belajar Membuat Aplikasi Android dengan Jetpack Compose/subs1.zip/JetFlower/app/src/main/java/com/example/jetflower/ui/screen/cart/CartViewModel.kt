package com.example.jetflower.ui.screen.cart

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.jetflower.data.Repository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import com.example.jetflower.data.Result

class CartViewModel (private val repository: Repository
) : ViewModel() {
    private val _uiState: MutableStateFlow<Result<CartState>> = MutableStateFlow(Result.Loading)
    val uiState: StateFlow<Result<CartState>>
    get() = _uiState

    fun getAddFlower() {
        viewModelScope.launch {
            _uiState.value = Result.Loading
            repository.getAddFlower()
                .collect { buyFlower ->
                    val totalPrice =
                        buyFlower.sumOf { it.flower.price * it.count }
                    _uiState.value = Result.Success(CartState(buyFlower, totalPrice))
                }
        }
    }

    fun updateFlower(flowerId: Long, count: Int) {
        viewModelScope.launch {
            repository.updateFlower(flowerId, count)
                .collect { isUpdated ->
                    if (isUpdated) {
                        getAddFlower()
                    }
                }
        }
    }
}