package com.example.jetflower.ui.screen.home

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.jetflower.data.FlowerItem
import com.example.jetflower.data.Result
import com.example.jetflower.di.Injection
import com.example.jetflower.ui.ViewModelFactory
import com.example.jetflower.ui.components.FlowerItems
import com.example.jetflower.ui.components.SearchBarProses


@Composable
fun HomeScreen(
    modifier: Modifier = Modifier,
    viewModel: HomeViewModel = viewModel(
        factory = ViewModelFactory(Injection.provideRepository())
    ),
    navigateToDetail : (Long) -> Unit,
    ) {

    val searchState by viewModel.searchState

    viewModel.state.collectAsState(initial = Result.Loading).value.let { state ->
        when (state){
            is Result.Loading -> {
                viewModel.getAllFlower()
            }
            is Result.Success -> {
                HomeContent(
                    flowerItem = state.data,
                    modifier = modifier,
                    navigateToDetail = navigateToDetail,
                    query = searchState.query,
                    onQueryChange = viewModel::onQueryChange
                )
            }
            is Result.Error -> {}
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeContent(
    flowerItem: List<FlowerItem>,
    modifier: Modifier = Modifier,
    navigateToDetail: (Long) -> Unit,
    query: String,
    onQueryChange: (String) -> Unit,

    ) {
    Column(
        modifier = modifier.fillMaxSize()
    ) {

        SearchBarProses(
            query = query ,
            onQueryChange = onQueryChange,
            modifier = Modifier.background(MaterialTheme.colorScheme.primary)
        )
        LazyVerticalGrid(
            columns = GridCells.Adaptive(160.dp),
            contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = modifier
        ) {
            items(flowerItem) { item ->
                FlowerItems(
                    title = item.flower.title,
                    photo = item.flower.photo,
                    price = item.flower.price,
                    modifier = Modifier
                        .clickable {
                        navigateToDetail(item.flower.id)
                    }
                )
            }
        }
    }
}