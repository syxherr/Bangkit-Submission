package com.example.jetflower.data

data class FlowerItem(
    val flower: FlowerModel,
    val count: Int
)