package com.example.jetflower.data

import com.example.jetflower.R

object FlowerData {
    val flowerModels = listOf(
        FlowerModel(
            1,
            "Mawar",
            "Mawar dikenal dengan aroma manisnya dan keberagaman warnanya, mulai dari merah muda yang lembut hingga merah mendalam. Setiap warna mawar memiliki simbolisme khusus, misalnya, \n" +
                    " merah melambangkan cinta yang mendalam. Mawar tumbuh dalam berbagai varietas, termasuk mawar hibrida dan mawar rambling, menambah keunikan dan keindahan ke setiap taman.",
            R.drawable.mawar,
            10000
        ),
        FlowerModel(
            2,
            "Sunflower",
            "Bunga matahari, atau Helianthus, merupakan bunga yang mencolok dengan kepala bunga besar dan biji yang tersusun secara simetris. Mereka dikenal karena mengikuti gerakan matahari sepanjang hari.\n" +
                    "Selain simbolisme kebahagiaan dan keceriaan, bunga matahari juga memiliki kegunaan praktis sebagai tanaman penghasil minyak biji bunga matahari yang sehat.",
            R.drawable.sunflower,
            20000
        ),
        FlowerModel(
            3,
            "Lily",
            "Bunga lily, dengan keindahan dan aromanya yang khas, melambangkan kepolosan, keberuntungan, dan kehidupan baru. Tersedia dalam berbagai warna dan bentuk,\n" +
                    "lily menciptakan kehadiran yang megah di taman atau buket bunga. Beberapa varietas lily, seperti lily oriental, menghasilkan aroma yang khas dan memukau.",
            R.drawable.lily,
            30000
        ),

        FlowerModel(
            4,
            "Forget-Me-Not",
            "Bunga forget-me-not, atau Myosotis, merupakan bunga kecil yang cantik dengan warna biru lembut. \n" +
                    "Nama bunga ini mencerminkan makna simbolisnya yang melambangkan kesetiaan dan kenangan abadi. Forget-me-not sering digunakan dalam pengaturan taman dan melibatkan perasaan sentimental yang mendalam.",
            R.drawable.forget,
            40000
        ),

        FlowerModel(
            5,
            "Lavender",
            "Lavender adalah bunga yang dikenal dengan aroma yang menenangkan dan keindahan warna ungunya yang khas. Selain menjadi tanaman hias, \n" +
                    "lavender juga digunakan untuk minyak esensial yang memiliki sifat relaksasi. Lavender sering ditemukan di taman aroma dan dijadikan elemen utama dalam produk-produk perawatan tubuh dan kecantikan.",
            R.drawable.lavnder,
            50000
        ),

        FlowerModel(
            6,
            "Sakura",
            "Bunga sakura adalah simbol klasik Jepang yang melambangkan keindahan, kehidupan yang singkat, dan awal musim semi. Bunga-bunga berwarna pink atau putih ini menciptakan pemandangan yang spektakuler di musim sakura, \n" +
                    "dan festival sakura menjadi perayaan seni dan keindahan alam.",
            R.drawable.sakura,
            60000
        ),

        FlowerModel(
            7,
            "Anyelir",
            "Bunga anyelir adalah bunga yang elegan dengan berbagai warna seperti merah, putih, dan merah muda. Anyelir melambangkan keberanian, keanggunan, dan kasih sayang.\n" +
                    "Bunga ini sering digunakan dalam rangkaian bunga potong dan tahan lama.",
            R.drawable.anyeelir,
            70000
        ),

        FlowerModel(
            8,
            "Magnolia",
            "Bunga magnolia, dengan keindahan dan aroma yang memikat, adalah simbol keindahan dan kemurnian. Magnolia memiliki kelopak bunga yang besar dan beraneka warna, mulai dari putih murni hingga merah muda dan ungu.\n" +
                    "Pohon magnolia yang berbunga menjadi daya tarik utama di taman dan lingkungan perkotaan.",
            R.drawable.magnolia,
            80000
        ),

        FlowerModel(
            9,
            "Dahlia",
            "Bunga dahlia menarik perhatian dengan kepala bunga yang besar dan variasi warna yang luas. Dahlia adalah bunga yang penuh warna dan menawan, melambangkan keanggunan dan kemegahan.\n" +
                    "Mereka dapat ditemukan dalam berbagai bentuk, mulai dari bunga berpenuh hingga bunga dengan kelopak bergelombang.",
            R.drawable.dahlia,
            90000
        ),

        FlowerModel(
            10,
            "Peony",
            "Bunga peony, atau Paeonia, adalah bunga yang indah dan mewah dengan kelopak bunga yang lebat dan besar. Peony melambangkan kekayaan, kehormatan, dan kebahagiaan.\n" +
                    "Tersedia dalam berbagai warna, seperti merah, merah muda, putih, dan kuning, peony sering menjadi bintang dalam taman-taman tradisional dan dijadikan bunga potong yang populer.",
            R.drawable.peony,
            100000)
    )
}