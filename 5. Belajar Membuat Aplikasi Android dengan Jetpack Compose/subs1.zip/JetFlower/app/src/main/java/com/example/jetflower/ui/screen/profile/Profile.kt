package com.example.jetflower.ui.screen.profile

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.material3.Text
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.tooling.preview.Devices
import androidx.compose.ui.tooling.preview.Preview
import com.example.jetflower.R
import com.example.jetflower.ui.theme.JetFlowerTheme

@Composable
fun ProfileScreen(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize(),
        contentAlignment = Alignment.Center,
        ) {
        Column {
            Image(
                painter = painterResource(id = R.drawable.profile),
                contentDescription = "about_page",
                modifier = Modifier
                    .clip(CircleShape)
                    .size(155.dp)
                    .align(Alignment.CenterHorizontally)
            )
            Text(
                text = stringResource(id = R.string.name),
                style = TextStyle(
                    fontSize = 20.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
            ),
            modifier = Modifier
                .width(250.dp)
                .padding(top = 16.dp)
            )
            Text(
                text = stringResource(id = R.string.email),
                style = TextStyle(
                    fontSize = 16.sp,
                    textAlign = TextAlign.Center
                ),
                modifier = Modifier
                    .width(250.dp)
                    .padding(top = 4.dp)
            )
        }
    }
}
@Preview(showBackground = true, device = Devices.NEXUS_6P)
@Composable
fun DetailContentPreview(){
    JetFlowerTheme {
        ProfileScreen(
        )
    }
}
