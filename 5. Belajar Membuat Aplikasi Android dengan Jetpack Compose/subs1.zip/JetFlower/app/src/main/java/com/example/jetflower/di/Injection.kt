package com.example.jetflower.di

import com.example.jetflower.data.Repository

object Injection {
    fun provideRepository(): Repository {
        return Repository.getInstance()
    }
}