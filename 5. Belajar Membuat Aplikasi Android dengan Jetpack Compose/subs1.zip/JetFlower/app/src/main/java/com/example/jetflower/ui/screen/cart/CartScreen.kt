package com.example.jetflower.ui.screen.cart

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.jetflower.R
import com.example.jetflower.di.Injection
import com.example.jetflower.data.Result
import com.example.jetflower.ui.ViewModelFactory
import com.example.jetflower.ui.components.BuyBotton
import com.example.jetflower.ui.components.BuyItem

@Composable
fun CartScreen(
    viewModel: CartViewModel = viewModel(
        factory = ViewModelFactory(
            Injection.provideRepository()
        )
    ),
    onOrderButtonCLicked : (String) -> Unit,
) {
    viewModel.uiState.collectAsState(initial = Result.Loading).value.let { state ->
        when (state) {
            is Result.Loading -> {
                viewModel.getAddFlower()
            }
            is Result.Success -> {
                CartContent(
                    state.data,
                    onProductCountChanged = {rewardId, count ->
                        viewModel.updateFlower(rewardId,count)
                    },
                    onOrderButtonCLicked = onOrderButtonCLicked
                )
            }
            is Result.Error -> {}
        }
    }

}

//membuat cart

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartContent(
    state: CartState,
    onProductCountChanged : (id : Long, count: Int) -> Unit,
    onOrderButtonCLicked: (String) -> Unit,
    modifier: Modifier = Modifier
){
    val shareMessage = stringResource(
        R.string.share_message,
        state.orderFlower.count(),
        state.totalPrice
    )
    Column(
        modifier = modifier.fillMaxSize()
    ) {
        CenterAlignedTopAppBar(
            title = {
                Text(
                    text = stringResource(R.string.menu_cart),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    textAlign = TextAlign.Center
                )
            }
        )
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(weight = 1f)
        ){
            items(state.orderFlower, key ={it.flower.id }) { item ->
                BuyItem(
                    flowerId = item.flower.id,
                    photo = item.flower.photo,
                    title = item.flower.title,
                    price = item.flower.price * item.count,
                    count = item.count,
                    onProductCountChanged = onProductCountChanged
                )
                Divider()
            }
        }
        BuyBotton(
            text = stringResource(R.string.total_order, state.totalPrice),
            enabled = state.orderFlower.isNotEmpty(),
            onClick = {
                onOrderButtonCLicked(shareMessage)
            },
            modifier = Modifier.padding(16.dp)
        )
    }
}