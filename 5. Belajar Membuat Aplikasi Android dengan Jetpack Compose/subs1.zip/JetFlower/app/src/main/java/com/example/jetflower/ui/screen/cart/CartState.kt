package com.example.jetflower.ui.screen.cart

import com.example.jetflower.data.FlowerItem

data class CartState(
    val orderFlower: List<FlowerItem>,
    val totalPrice: Int
)