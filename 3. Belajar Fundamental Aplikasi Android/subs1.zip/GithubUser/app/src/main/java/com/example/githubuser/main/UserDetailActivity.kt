package com.example.githubuser.main

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import androidx.activity.viewModels
import androidx.annotation.StringRes
import com.bumptech.glide.Glide
import com.example.githubuser.R
import com.example.githubuser.api.SectionsAdapter
import com.example.githubuser.databinding.ActivityUserDetailBinding
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class UserDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUserDetailBinding
    private val detailViewModel by viewModels<DetailViewModel>()



    companion object {
        const val EXTRA_LOGIN = "extra_login"
        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.followers,
            R.string.following
        )
    }
    private fun hideActionBar() {
        supportActionBar?.hide()

    }
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserDetailBinding.inflate(layoutInflater)
        hideActionBar()
        setContentView(binding.root)


        val usernameData = intent.getStringExtra(EXTRA_LOGIN).toString()
        detailViewModel.getUserData(usernameData)


        detailViewModel.isLoadingDetail.observe(this) {isLoading ->
            showLoading(isLoading)
        }
        detailViewModel.username.observe(this) { username ->
            binding.UsernameDetail.text = username
        }

        detailViewModel.name.observe(this) { name ->
            binding.tvNameDetail.text = name
        }

        detailViewModel.picture.observe(this) { picture ->
            Glide.with(this@UserDetailActivity)
                .load(picture).circleCrop().into(binding.ProfileDetail)
        }

        detailViewModel.following.observe(this) { following ->
            binding.tvFollowing.text = "$following Following"
        }

        detailViewModel.followers.observe(this) { followers ->
            binding.tvFollowers.text = "$followers Followers"
        }

        val sectionsPagerAdapter = SectionsAdapter(this)
        binding.view.adapter = sectionsPagerAdapter
        val tabs: TabLayout = binding.tabs
        TabLayoutMediator(tabs, binding.view) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

        detailViewModel.getUserFollowers(usernameData)
    }
    private fun showLoading(state: Boolean) {
        val progressBar = findViewById<ProgressBar>(R.id.progressBar3)
        if (state) {
            progressBar.visibility = View.VISIBLE
        } else {
            progressBar.visibility = View.INVISIBLE
        }
    }
}