package com.example.githubuser.main

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubuser.ItemsItem
import com.example.githubuser.api.UserAdapter
import com.example.githubuser.databinding.FragmentFollowersBinding

class Followers : Fragment() {

    private var _binding: FragmentFollowersBinding? = null
    private val binding get() = _binding!!
    private lateinit var followersViewModel: FollowersViewModel
    private lateinit var detailViewModel: DetailViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFollowersBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val layoutManager = LinearLayoutManager(context)
        binding.Followers.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(context, layoutManager.orientation)
        binding.Followers.addItemDecoration(itemDecoration)
        followersViewModel = ViewModelProvider(this)[FollowersViewModel::class.java]
        detailViewModel = ViewModelProvider(requireActivity())[DetailViewModel::class.java]

        detailViewModel.isLoadingFollowers.observe(viewLifecycleOwner) { isLoading ->
            showLoading(isLoading)
        }
        detailViewModel.detailFollowers.observe(viewLifecycleOwner) { detailFollowers ->
            setUserFollowers(detailFollowers)
        }
        val username = detailViewModel.username.value
        if (username != null) {
            followersViewModel.getUserFollowers(username)
        }
    }

    private fun setUserFollowers(userFollowers: List<ItemsItem>) {
        val list = ArrayList<ItemsItem>()
        for (user in userFollowers) {
            list.addAll(listOf(user))
        }
        binding.Followers.adapter = UserAdapter(list)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun showLoading(state: Boolean) {
        if (state) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.INVISIBLE
        }
    }
}
