// MainActivity.kt
package com.example.githubuser.main

import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.widget.ProgressBar
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubuser.ItemsItem
import com.example.githubuser.R
import com.example.githubuser.api.UserAdapter
import com.example.githubuser.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val mainViewModel by viewModels<MainViewModel>()
    private lateinit var adapter: UserAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()

        setupRecyclerView()

        mainViewModel.username.observe(this, ::setUserData)
        mainViewModel.isLoading.observe(this, ::showLoading)

        binding.btnSearch.setOnClickListener {
            val query = binding.search.text.toString()
            if (query.isNotEmpty()) {
                searchUser(query)
            }
        }

        binding.search.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER) {
                val query = binding.search.text.toString()
                if (query.isNotEmpty()) {
                    searchUser(query)
                }
                return@setOnKeyListener true
            }
            return@setOnKeyListener false
        }
    }

    private fun setUserData(userData: List<ItemsItem>) {
        adapter.setList(userData)
    }

    private fun setupRecyclerView() {
        val layoutManager = LinearLayoutManager(this)
        binding.rvUser.layoutManager = layoutManager
        binding.rvUser.addItemDecoration(DividerItemDecoration(this, layoutManager.orientation))
        adapter = UserAdapter(ArrayList())
        binding.rvUser.adapter = adapter
    }

    private fun searchUser(query: String) {
        if (query.isNotEmpty()) {
            showLoading(true)
            mainViewModel.findUser(query)
        }
    }



    private fun showLoading(state: Boolean) {
        val progressBar = findViewById<ProgressBar>(R.id.progressBar)
        if (state) {
            progressBar.visibility = View.VISIBLE
        } else {
            progressBar.visibility = View.GONE
        }
    }

}
