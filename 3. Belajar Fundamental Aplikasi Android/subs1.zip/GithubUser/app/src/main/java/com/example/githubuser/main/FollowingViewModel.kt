package com.example.githubuser.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.githubuser.ItemsItem
import com.example.githubuser.api.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FollowingViewModel : ViewModel() {
    private val _detailFollowing = MutableLiveData<List<ItemsItem>>()
    val detailFollowing: LiveData<List<ItemsItem>> = _detailFollowing
    private val _isLoadingFollowing = MutableLiveData<Boolean>()

    fun getUserFollowing(username: String) {
        _isLoadingFollowing.value = true
        val client = ApiConfig.getApiService().getFollowing(username)
        client.enqueue(object : Callback<List<ItemsItem>> {
            override fun onResponse(
                call: Call<List<ItemsItem>>,
                response: Response<List<ItemsItem>>
            ) {
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        _detailFollowing.value = responseBody
                    }
                }
                _isLoadingFollowing.value = false
            }

            override fun onFailure(call: Call<List<ItemsItem>>, t: Throwable) {
                _isLoadingFollowing.value = false
            }
        })
    }
}