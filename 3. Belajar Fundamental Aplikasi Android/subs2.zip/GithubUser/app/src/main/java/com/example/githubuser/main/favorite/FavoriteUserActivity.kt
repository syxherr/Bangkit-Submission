package com.example.githubuser.main.favorite

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubuser.data.local.database.AndroidApplication
import com.example.githubuser.data.local.database.FavoriteUser
import com.example.githubuser.databinding.ActivityFavoriteUserBinding
import com.example.githubuser.main.DetailActivity

class FavoriteUserActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFavoriteUserBinding
    private val favoriteViewModel: FavoriteUserViewModel by viewModels {
        FavoriteUserViewModel.FavoriteViewModelFactory(
            (application as AndroidApplication).database.FavoriteDao()
        )
    }
    private val adapter: UserFavoriteAdapter by lazy { UserFavoriteAdapter(this::onItemClicked) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavoriteUserBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()


        setupRecyclerView()
        observeFavoriteUsers()
    }

    private fun setupRecyclerView() {
        binding.rvUser.layoutManager = LinearLayoutManager(this)
        binding.rvUser.adapter = adapter
    }

    private fun observeFavoriteUsers() {
        favoriteViewModel.allUsersFav.observe(this) { items ->
            items?.let { adapter.submitList(it) }
        }
    }

    private fun onItemClicked(favoriteUser: FavoriteUser) {
        val intent = Intent(this, DetailActivity::class.java)
        intent.putExtra(DetailActivity.Username, favoriteUser.username)
        startActivity(intent)
    }
}
