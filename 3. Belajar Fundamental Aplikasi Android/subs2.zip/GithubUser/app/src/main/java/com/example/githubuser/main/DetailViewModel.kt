package com.example.githubuser.main

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.githubuser.api.ItemsUser
import com.example.githubuser.api.ApiConfig
import com.example.githubuser.api.UserDetailResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailViewModel(application: Application) : AndroidViewModel(application){
    private val _username = MutableLiveData<String>()
    val username: MutableLiveData<String> = _username
    private val _name = MutableLiveData<String>()
    val name: LiveData<String> = _name
    private val _picture = MutableLiveData<String>()
    val picture: LiveData<String> = _picture
    private val _followers = MutableLiveData<String>()
    val followers: LiveData<String> = _followers
    private val _following = MutableLiveData<String>()
    val following: LiveData<String> = _following
    private val _isLoadingDetail = MutableLiveData<Boolean>()
    val isLoadingDetail: LiveData<Boolean> = _isLoadingDetail
    private val _detailFollowers = MutableLiveData<List<ItemsUser>>()
    val detailFollowers: LiveData<List<ItemsUser>> = _detailFollowers
    private val _isLoadingFollowers = MutableLiveData<Boolean>()
    val isLoadingFollowers: LiveData<Boolean> = _isLoadingFollowers
    private val _isLoadingFollowing = MutableLiveData<Boolean>()
    val isLoadingFollowing: LiveData<Boolean> = _isLoadingFollowing

    private val _user = MutableLiveData<UserDetailResponse>()
    val user: LiveData<UserDetailResponse> = _user


    companion object {
        private const val TAG = "DetailViewModel"
    }

    fun getUserData(username: String) {
        _isLoadingDetail.value = true
        val client = ApiConfig.getApiService().getDetailUser(username)
        client.enqueue(object : Callback<UserDetailResponse> {
            override fun onResponse(
                call: Call<UserDetailResponse>,
                response: Response<UserDetailResponse>
            ) {
                if (response.isSuccessful) {
                    _user.value = response.body()

                    val responseBody = response.body()
                    if (responseBody != null) {
                        _username.value = responseBody.login
                        _name.value = responseBody.name
                        _picture.value = responseBody.avatarUrl
                        _followers.value = responseBody.followers.toString()
                        _following.value = responseBody.following.toString()


                    }
                }
                _isLoadingDetail.value = false
            }

            override fun onFailure(call: Call<UserDetailResponse>, t: Throwable) {
                _isLoadingDetail.value = false
            }
        })
    }
    fun getUserFollowers(username: String) {
        _isLoadingFollowers.value = true
        val client = ApiConfig.getApiService().getFollowers(username)
        client.enqueue(object : Callback<List<ItemsUser>> {
            override fun onResponse(
                call: Call<List<ItemsUser>>,
                response: Response<List<ItemsUser>>
            ) {
                _isLoadingFollowers.value = false
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        _detailFollowers.value = response.body()
                    } else {
                        Log.e(TAG, "onFailure: ${response.message()}")
                    }
                }
            }

            override fun onFailure(call: Call<List<ItemsUser>>, t: Throwable) {
                _isLoadingFollowers.value = false
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

}