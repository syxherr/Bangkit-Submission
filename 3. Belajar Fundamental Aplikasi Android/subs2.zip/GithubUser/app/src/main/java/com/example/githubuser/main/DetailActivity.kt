package com.example.githubuser.main

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.githubuser.R
import com.example.githubuser.api.SectionsAdapter
import com.example.githubuser.api.UserDetailResponse
import com.example.githubuser.data.local.database.AndroidApplication
import com.example.githubuser.data.local.database.FavoriteUser
import com.example.githubuser.databinding.ActivityUserDetailBinding
import com.example.githubuser.main.favorite.FavoriteUserViewModel
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUserDetailBinding
    private val detailViewModel by viewModels<DetailViewModel>()
    private lateinit var user: UserDetailResponse

    private val favoriteViewModel: FavoriteUserViewModel by viewModels {
        FavoriteUserViewModel.FavoriteViewModelFactory(
            (application as AndroidApplication).database.FavoriteDao()
        )
    }

    companion object {
        const val Username = "login"

        private var status = true

        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.followers,
            R.string.following
        )
    }

    private fun hideActionBar() {
        supportActionBar?.hide()
    }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserDetailBinding.inflate(layoutInflater)
        hideActionBar()
        setContentView(binding.root)

        val usernameData = intent.getStringExtra(Username).toString()
        detailViewModel.getUserData(usernameData)

        detailViewModel.isLoadingDetail.observe(this) { isLoading ->
            showLoading(isLoading)
        }

        detailViewModel.username.observe(this) { username ->
            binding.UsernameDetail.text = username
        }

        detailViewModel.name.observe(this) { name ->
            binding.tvNameDetail.text = name
        }

        detailViewModel.picture.observe(this) { picture ->
            Glide.with(this)
                .load(picture)
                .circleCrop()
                .into(binding.ProfileDetail)
        }

        detailViewModel.following.observe(this) { following ->
            binding.tvFollowing.text = "$following Following"
        }

        detailViewModel.followers.observe(this) { followers ->
            binding.tvFollowers.text = "$followers Followers"
        }

        val sectionsPagerAdapter = SectionsAdapter(this)
        binding.view.adapter = sectionsPagerAdapter
        val tabs: TabLayout = binding.tabs
        TabLayoutMediator(tabs, binding.view) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

        detailViewModel.getUserFollowers(usernameData)

        detailViewModel.user.observe(this) { user ->
            this.user = user

            user.isFavorite = favoriteViewModel.allUsersFav.value?.contains(
                FavoriteUser(
                    user.login,
                    user.avatarUrl
                )
            ) == true

            favoriteViewModel.allUsersFav.observe(this) { favorites ->
                val status = !favorites.contains(FavoriteUser(user.login, user.avatarUrl))
                if (status) {
                    binding.favoriteButton.setImageResource(R.drawable.iv_fav_gray)
                } else {
                    binding.favoriteButton.setImageResource(R.drawable.iv_fav_red)

                }
            }

            favoritesUser()
        }
    }

    private fun showLoading(state: Boolean) {
        val progressBar = findViewById<ProgressBar>(R.id.progressBar3)
        progressBar.visibility = if (state) View.VISIBLE else View.INVISIBLE
    }

    private fun favoritesUser() {
        binding.favoriteButton.setOnClickListener {
            val fUser = FavoriteUser(
                username = user.login,
                avatarUrl = user.avatarUrl
            )

            favoriteViewModel.allUsersFav.observe(this) {
                status = !it.contains(fUser)
            }

            if (status) {
                favoriteViewModel.insert(fUser)
                binding.favoriteButton.setImageResource(R.drawable.iv_fav_gray)
                Toast.makeText(this, "User has been added to favorites!", Toast.LENGTH_SHORT).show()
            } else {
                favoriteViewModel.delete(fUser)
                binding.favoriteButton.setImageResource(R.drawable.iv_fav_red)
                Toast.makeText(this, "User has been removed from favorites!", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
