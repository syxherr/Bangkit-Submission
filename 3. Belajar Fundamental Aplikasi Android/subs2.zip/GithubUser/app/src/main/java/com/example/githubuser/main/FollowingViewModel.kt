package com.example.githubuser.main

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.githubuser.api.ItemsUser
import com.example.githubuser.api.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FollowingViewModel : ViewModel() {
    private val _detailFollowing = MutableLiveData<List<ItemsUser>>()
    val detailFollowing: LiveData<List<ItemsUser>> = _detailFollowing
    private val _isLoadingFollowing = MutableLiveData<Boolean>()

    fun getUserFollowing(username: String) {
        _isLoadingFollowing.value = true
        val client = ApiConfig.getApiService().getFollowing(username)
        client.enqueue(object : Callback<List<ItemsUser>> {
            override fun onResponse(
                call: Call<List<ItemsUser>>,
                response: Response<List<ItemsUser>>
            ) {
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        _detailFollowing.value = responseBody
                    }
                }
                _isLoadingFollowing.value = false
            }

            override fun onFailure(call: Call<List<ItemsUser>>, t: Throwable) {
                _isLoadingFollowing.value = false
            }
        })
    }
}