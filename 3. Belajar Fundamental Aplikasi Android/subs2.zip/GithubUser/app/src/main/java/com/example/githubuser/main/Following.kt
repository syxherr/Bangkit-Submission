package com.example.githubuser.main

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubuser.api.ItemsUser
import com.example.githubuser.api.UserAdapter
import com.example.githubuser.databinding.FragmentFollowingBinding

class Following : Fragment() {

    private var _binding: FragmentFollowingBinding? = null
    private val binding get() = _binding!!
    private lateinit var followingViewModel: FollowingViewModel
    private lateinit var detailViewModel: DetailViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentFollowingBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val layoutManager = LinearLayoutManager(context)
        binding.Followings.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(context, layoutManager.orientation)
        binding.Followings.addItemDecoration(itemDecoration)
        followingViewModel = ViewModelProvider(this)[FollowingViewModel::class.java]
        detailViewModel = ViewModelProvider(requireActivity())[DetailViewModel::class.java]

        detailViewModel.isLoadingFollowing.observe(viewLifecycleOwner) { isLoading ->
            showLoading(isLoading)
        }
        followingViewModel.detailFollowing.observe(viewLifecycleOwner) { detailFollowing ->
            setUserFollowing(detailFollowing)
        }
        val username = detailViewModel.username.value
        if (username != null) {
            followingViewModel.getUserFollowing(username)
        }
    }

    private fun setUserFollowing(userFollowing: List<ItemsUser>) {
        val list = ArrayList<ItemsUser>()
        for (user in userFollowing) {
            list.add(user)
        }
        binding.Followings.adapter = UserAdapter(list)
        showLoading(false)
    }

    override fun onDestroy() {
        super.onDestroy()
        _binding = null
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar2.visibility = View.VISIBLE
        } else {
            binding.progressBar2.visibility = View.INVISIBLE
        }
    }
}
