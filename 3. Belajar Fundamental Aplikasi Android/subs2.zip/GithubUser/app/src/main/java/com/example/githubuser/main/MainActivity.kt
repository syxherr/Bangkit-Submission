package com.example.githubuser.main

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.PopupMenu
import android.widget.ProgressBar
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubuser.api.ItemsUser
import com.example.githubuser.R
import com.example.githubuser.api.UserAdapter
import com.example.githubuser.databinding.ActivityMainBinding
import com.example.githubuser.main.favorite.FavoriteUserActivity
import com.example.githubuser.theme.SettingPreferences
import com.example.githubuser.theme.ThemeActivity
import com.example.githubuser.theme.ThemeViewModel
import com.example.githubuser.theme.ViewModelFactory
import com.example.githubuser.theme.dataStore

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val mainViewModel by viewModels<MainViewModel>()
    private lateinit var adapter: UserAdapter


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()

        setupRecyclerView()
        themeMain()

        mainViewModel.username.observe(this, ::setUserData)
        mainViewModel.isLoading.observe(this, ::showLoading)

        binding.btnSearch.setOnClickListener {
            val query = binding.search.text.toString()
            if (query.isNotEmpty()) {
                searchUser(query)
            }
        }

        binding.search.setOnKeyListener { _, keyCode, event ->
            if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER) {
                val query = binding.search.text.toString()
                if (query.isNotEmpty()) {
                    searchUser(query)
                }
                return@setOnKeyListener true
            }
            return@setOnKeyListener false
        }

        binding.btnMenu.setOnClickListener { it ->
            showPopupMenu(it)
        }

    }

    private fun themeMain() {
        val preference = SettingPreferences.getInstance(application.dataStore)
        val mainViemModel = ViewModelProvider(this, ViewModelFactory(preference))[ThemeViewModel::class.java]

        mainViemModel.getThemeSet().observe(this) { isDarkMode: Boolean ->
            if (isDarkMode) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }
    }

    private fun setUserData(userData: List<ItemsUser>) {
        adapter.setList(userData)
    }

    private fun setupRecyclerView() {
        val layoutManager = LinearLayoutManager(this)
        binding.rvUser.layoutManager = layoutManager
        binding.rvUser.addItemDecoration(DividerItemDecoration(this, layoutManager.orientation))
        adapter = UserAdapter(ArrayList())
        binding.rvUser.adapter = adapter
    }

    private fun searchUser(query: String) {
        if (query.isNotEmpty()) {
            showLoading(true)
            mainViewModel.findUser(query)
        }
    }

    private fun showLoading(state: Boolean) {
        val progressBar = findViewById<ProgressBar>(R.id.progressBar)
        if (state) {
            progressBar.visibility = View.VISIBLE
        } else {
            progressBar.visibility = View.GONE
        }
    }

    private fun showPopupMenu(v: View) {
        val popupMenu = PopupMenu(this, v, Gravity.END) // Tambahkan Gravity.END
        popupMenu.menuInflater.inflate(R.menu.option_menu, popupMenu.menu)

        popupMenu.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.favorite_menu -> {
                    val intent = Intent(this@MainActivity, FavoriteUserActivity::class.java)
                    startActivity(intent)
                    true
                }
                R.id.menuSetMode -> {
                    val intent = Intent(this@MainActivity, ThemeActivity::class.java)
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }

        // Menggunakan refleksi untuk mengakses field 'mPopup' dalam PopupMenu
        try {
            val field = popupMenu.javaClass.getDeclaredField("mPopup")
            field.isAccessible = true
            val popup = field.get(popupMenu)
            popup.javaClass.getDeclaredMethod("setForceShowIcon", Boolean::class.java).invoke(popup, true)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        popupMenu.show()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.option_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.favorite_menu -> {
                val intent = Intent(this@MainActivity, FavoriteUserActivity::class.java)
                startActivity(intent)
                true
            }
            R.id.menuSetMode -> {
                val intent = Intent(this@MainActivity, ThemeActivity::class.java)
                startActivity(intent)
                true
            }

        }
        return super.onOptionsItemSelected(item)
    }

}
