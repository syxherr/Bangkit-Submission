package com.example.githubuser.data.local.database

import android.app.Application

class AndroidApplication : Application() {
    val database: FavRoomDatabase by lazy { FavRoomDatabase.getDatabase(this) }
}

