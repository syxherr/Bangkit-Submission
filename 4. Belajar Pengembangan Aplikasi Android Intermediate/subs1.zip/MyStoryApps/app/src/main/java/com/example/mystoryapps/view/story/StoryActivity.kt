package com.example.mystoryapps.view.story

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.mystoryapps.data.pref.Result
import com.example.mystoryapps.databinding.ActivityStoryBinding
import com.example.mystoryapps.view.ViewModelFactory
import com.example.mystoryapps.view.main.MainActivity
import com.example.mystoryapps.view.reduceFile
import com.example.mystoryapps.view.rotateBitmap
import com.example.mystoryapps.view.uriFile
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.text.SimpleDateFormat
import java.util.Locale

class StoryActivity : AppCompatActivity() {

    private lateinit var binding: ActivityStoryBinding
    private lateinit var imagePath: String
    private lateinit var factory: ViewModelFactory
    private var fileStory: File? = null
    private val storyViewModel: StoryViewModel by viewModels { factory }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStoryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        factory = ViewModelFactory.getInstance(this)
        supportActionBar?.hide()


        if (!allPermissionsGranted()) {
            ActivityCompat.requestPermissions(
                this,
                REQUIRED_PERMISSIONS,
                REQUEST_CODE_PERMISSIONS
            )
        }

        observeImageFile()
        showLoading()
        setupAction()
    }


    private fun setupAction() {
        binding.btnGallery.setOnClickListener { openGallery() }
        binding.btnCamera.setOnClickListener { openCamera() }
        binding.btnStory.setOnClickListener { uploadImage() }
    }

    private fun openCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        intent.resolveActivity(packageManager)
        val customTempFile = File.createTempFile(SimpleDateFormat(
                "dd-MMM-yyyy",
                Locale.US).format(System.currentTimeMillis()),
            ".jpg", getExternalFilesDir(Environment.DIRECTORY_PICTURES))
        customTempFile.also {
            imagePath = it.absolutePath
            intent.putExtra(
                MediaStore.EXTRA_OUTPUT, FileProvider.getUriForFile(
                    this@StoryActivity,
                    "com.example.mystoryapps.fileprovider",
                    it
                )
            )
            launchCamera.launch(intent)
        }
    }

    private val launchCamera = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == RESULT_OK) {
            val myFile = File(imagePath)
            fileStory = myFile
            val resultBitmap = rotateBitmap(BitmapFactory.decodeFile(fileStory?.path), true)
            binding.imgAddStory.setImageBitmap(resultBitmap)
            storyViewModel.imageFile.postValue(fileStory)

        }
    }

    private val launchGallery = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) {
                val selectedImg: Uri = result.data?.data as Uri
                val myFile = uriFile(selectedImg, this)
                fileStory = myFile
                binding.imgAddStory.setImageURI(selectedImg)
                storyViewModel.imageFile.postValue(fileStory)
            }
        }

    private fun openGallery() {
        val intent = Intent().apply {
            action = Intent.ACTION_GET_CONTENT
            type = "image/*"
        }
        val chooser = Intent.createChooser(intent, "Choose a Picture")
        launchGallery.launch(chooser)
    }

    private fun uploadImage() {
        if (storyViewModel.imageFile.value == null) {
            showToast("Image must be filled!")
        } else if (binding.descriptionEditText.text.toString().isEmpty()) {
            showToast("Description must be filled!")
        } else {
            storyViewModel.imageFile.observe(this@StoryActivity) {
                if (it != null) {
                    val imageFile = reduceFile(it)
                    val requestImageFile = imageFile.asRequestBody("image/jpeg".toMediaType())
                    val multipartBody = MultipartBody.Part.createFormData("photo", imageFile.name, requestImageFile)
                    storyViewModel.uploadStory(
                        multipartBody,
                        binding.descriptionEditText.text.toString().toRequestBody("text/plain".toMediaType())
                    ).observe(this) { result ->
                        if (result != null) {
                            when (result) {
                                is Result.Success -> {
                                    storyViewModel.isLoading.postValue(false)
                                    showToast(result.data.message)
                                    val intent = Intent(this@StoryActivity, MainActivity::class.java)
                                    finishAffinity()
                                    startActivity(intent)
                                }

                                is Result.Loading -> {
                                    storyViewModel.isLoading.postValue(true)
                                }

                                is Result.Error -> {
                                    storyViewModel.isLoading.postValue(false)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun observeImageFile() {
        storyViewModel.imageFile.observe(this@StoryActivity) {
            binding.imgAddStory.setImageBitmap(BitmapFactory.decodeFile(it.path))
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }


    private fun allPermissionsGranted() = REQUIRED_PERMISSIONS.all {
        ContextCompat.checkSelfPermission(baseContext, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun showLoading() {
        storyViewModel.isLoading.observe(this) {
            binding.progressBar.visibility = if (it) View.VISIBLE else View.GONE
        }
    }

    companion object {
        private const val REQUEST_CODE_PERMISSIONS = 10
        private val REQUIRED_PERMISSIONS = arrayOf(Manifest.permission.CAMERA)
    }
}
