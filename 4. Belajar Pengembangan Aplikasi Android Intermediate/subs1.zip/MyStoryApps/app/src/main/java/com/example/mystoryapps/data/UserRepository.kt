package com.example.mystoryapps.data

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.asLiveData
import androidx.lifecycle.liveData
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.liveData
import com.example.mystoryapps.data.pref.Result
import com.example.mystoryapps.data.pref.UserModel
import com.example.mystoryapps.data.pref.UserPreference
import com.example.mystoryapps.di.ApiService
import com.example.mystoryapps.response.ErrorResponse
import com.example.mystoryapps.response.ListStoryItem
import com.example.mystoryapps.response.LoginRequest
import com.example.mystoryapps.response.LoginResponse
import com.example.mystoryapps.response.LoginResult
import com.example.mystoryapps.response.RegisterRequest
import com.example.mystoryapps.response.RegisterResponse
import com.example.mystoryapps.view.story.Paging
import com.google.gson.Gson
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.HttpException
import retrofit2.Response

class UserRepository private constructor(
    private val userPreference: UserPreference,
    private val apiService: ApiService
) {
    private val _story = MutableLiveData<List<ListStoryItem>>()
    val story: LiveData<List<ListStoryItem>> = _story

    private val _registerUser = MutableLiveData<RegisterResponse>()

    private val _successMessage = MutableLiveData<String?>()
    val successMessage: MutableLiveData<String?> = _successMessage

    private val _errorLiveData = MutableLiveData<String?>()
    val errorLiveData: MutableLiveData<String?> = _errorLiveData

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    fun registerUser(name: String, email: String, password: String) {
        _isLoading.value = true
        val client = apiService.register(name, email, password)
        client.enqueue(object : Callback<RegisterResponse> {
            override fun onResponse(
                call: Call<RegisterResponse>,
                response: Response<RegisterResponse>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    _registerUser.value = response.body()
                    val successMessage = response.body()?.message
                    _successMessage.postValue(successMessage)


                } else {
                    val errorMessage = response.errorBody()?.string()
                    _errorLiveData.postValue(errorMessage)
                    Log.e("postRegister", "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                _isLoading.value = false
                Log.e("postRegister", "onFailure: ${t.message}")
            }
        })
    }

    fun loginUser(loginRequest: LoginRequest): Flow<Result<LoginResult?>> = flow {
        emit(Result.Loading)
        try {
            val responseLogin = apiService.loginAcc(loginRequest.email, loginRequest.password)
            val result = responseLogin.loginResult
            emit(Result.Success(result))
        } catch (e: HttpException) {
            val errorBody = e.response()?.errorBody()?.string()
            val errorResponse = Gson().fromJson(errorBody, LoginResponse::class.java)
            emit(Result.Error(errorResponse.message ?: "Unknown error"))
        }
    }

    fun getStories(token: String): LiveData<PagingData<ListStoryItem>> {
        return Pager(
            config = PagingConfig(pageSize = 5),
            pagingSourceFactory = {
                Paging(userPreference, apiService)
            }
        ).liveData
    }

    fun uploadStory(file: MultipartBody.Part, description: RequestBody) = liveData {
        emit(Result.Loading)
        try {
            val token = userPreference.getSession().first().token
            val successResponse = apiService.uploadStory("Bearer $token", file, description)
            emit(Result.Success(successResponse))
        } catch (e: HttpException) {
            val errorBody = e.response()?.errorBody()?.string()
            val errorResponse = Gson().fromJson(errorBody, ErrorResponse::class.java)
            emit(errorResponse.message?.let { Result.Error(it) })
        }
    }

    suspend fun saveSession(user: UserModel) {
        userPreference.saveSession(user)
    }

    fun getSession(): LiveData<UserModel> {
        return userPreference.getSession().asLiveData()
    }

    suspend fun logout() {
        userPreference.logout()
    }

    companion object {
        @Volatile
        private var instance: UserRepository? = null

        fun getInstance(
            userPreference: UserPreference,
            apiService: ApiService
        ): UserRepository =
            instance ?: synchronized(this) {
                instance ?: UserRepository(userPreference, apiService)
            }.also { instance = it }
    }
}
