package com.example.mystoryapps.view.story

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mystoryapps.data.UserRepository
import com.example.mystoryapps.data.pref.UserModel
import com.example.mystoryapps.response.AddStoryResponse
import kotlinx.coroutines.launch
import okhttp3.MultipartBody
import okhttp3.RequestBody
import java.io.File

class StoryViewModel(private val repository: UserRepository) : ViewModel() {

    val isLoading = MutableLiveData<Boolean>()
    val imageFile = MutableLiveData<File>()

    fun uploadStory(file: MultipartBody.Part, description: RequestBody) =
        repository.uploadStory(file, description)

}