package com.example.mystoryapps.view.register

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mystoryapps.data.UserRepository
import com.example.mystoryapps.response.RegisterRequest import kotlinx.coroutines.launch
import com.example.mystoryapps.data.pref.Result

class RegisterViewModel (private val repository: UserRepository): ViewModel() {

    private val _registerResult = MutableLiveData<Result<String?>>()
    val registerResult: LiveData<Result<String?>> = _registerResult

    val successMessage: MutableLiveData<String?> = repository.successMessage
    val errorLiveData: MutableLiveData<String?> = repository.errorLiveData
    val isLoading: LiveData<Boolean> = repository.isLoading

    fun registerUser(name: String, email: String, password: String) {
        viewModelScope.launch {
            repository.registerUser(name, email, password)
        }
    }

//    fun registerUser(registerRequest : RegisterRequest) {
//        viewModelScope.launch {
//            repository.registerUser(registerRequest).collect {
//                _registerResult.value = it
//            }
//        }
//    }
}