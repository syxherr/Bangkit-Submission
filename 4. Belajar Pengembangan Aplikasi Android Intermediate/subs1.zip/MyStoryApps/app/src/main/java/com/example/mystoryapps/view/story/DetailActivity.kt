package com.example.mystoryapps.view.story

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.mystoryapps.databinding.ActivityDetailBinding
import com.example.mystoryapps.response.ListStoryItem

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.hide()
        storyDetails()
    }

    private fun storyDetails() {
        val story = intent.getParcelableExtra<ListStoryItem>(EXTRA_STORY) as ListStoryItem
        binding.txtNama.text = story.name
        binding.txtDesc.text = story.description.orEmpty()
        Glide.with(this).load(story.photo).into(binding.imgPhotoDetail)
    }

    companion object {
        const val EXTRA_STORY = "extra_story"
    }

}