package com.example.mystoryapps.view.story

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.mystoryapps.data.UserRepository
import okhttp3.MultipartBody
import okhttp3.RequestBody
import java.io.File

class StoryViewModel(private val repository: UserRepository) : ViewModel() {

    val isLoading = MutableLiveData<Boolean>()
    val imageFile = MutableLiveData<File>()

    fun uploadStory(file: MultipartBody.Part, description: RequestBody) =
        repository.uploadStory(file, description)

}