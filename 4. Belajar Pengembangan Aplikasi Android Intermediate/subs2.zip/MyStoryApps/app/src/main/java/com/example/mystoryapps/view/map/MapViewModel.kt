package com.example.mystoryapps.view.map

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.mystoryapps.data.UserRepository
import com.example.mystoryapps.data.pref.UserModel
import com.example.mystoryapps.response.StoryResponse
import kotlinx.coroutines.launch

class MapViewModel (private val repository: UserRepository) : ViewModel() {
    val listStoryLocation: LiveData<StoryResponse> = repository.listStoryLocation

    fun getSession(): LiveData<UserModel> {
        return repository.getSession()
    }

    fun getStoriesLocation(token: String) {
        viewModelScope.launch {
            repository.getStoryLocation(token)
        }
    }
}