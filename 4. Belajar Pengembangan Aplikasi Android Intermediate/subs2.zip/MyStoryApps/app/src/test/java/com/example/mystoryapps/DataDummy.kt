package com.example.mystoryapps

import com.example.mystoryapps.response.ListStoryItem
import com.example.mystoryapps.response.StoryResponse

object DataDummy {
    fun generateDummyStoryResponse(): StoryResponse {
        val listStory: MutableList<ListStoryItem> = arrayListOf()
        for (i in 0..100) {
            val listStoryItem = ListStoryItem(
                createdAt = "2023-11-20T12:26:05Z",
                description = "Description $i",
                id = "id_$i",
                lat = i.toDouble() * 10,
                lon = i.toDouble() * 10,
                name = "Name $i",
                photo = "https://apod.nasa.gov/apod/image/2308/M66_JwstTomlinson_3521.jpg"
            )
            listStory.add(listStoryItem)
        }
        return StoryResponse(
            error = false, message = "Stories fetched successfully", listStory = listStory
        )
    }
}